﻿namespace OgamaClient
{
  partial class StarRating
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StarRating));
      this.pbStar5 = new System.Windows.Forms.PictureBox();
      this.pbStar1 = new System.Windows.Forms.PictureBox();
      this.pbStar2 = new System.Windows.Forms.PictureBox();
      this.pbStar3 = new System.Windows.Forms.PictureBox();
      this.pbStar4 = new System.Windows.Forms.PictureBox();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar5)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar2)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar3)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar4)).BeginInit();
      this.SuspendLayout();
      // 
      // pbStar5
      // 
      this.pbStar5.Image = ((System.Drawing.Image)(resources.GetObject("pbStar5.Image")));
      this.pbStar5.Location = new System.Drawing.Point(69, 3);
      this.pbStar5.Margin = new System.Windows.Forms.Padding(0);
      this.pbStar5.Name = "pbStar5";
      this.pbStar5.Size = new System.Drawing.Size(16, 16);
      this.pbStar5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
      this.pbStar5.TabIndex = 10;
      this.pbStar5.TabStop = false;
      // 
      // pbStar1
      // 
      this.pbStar1.Image = ((System.Drawing.Image)(resources.GetObject("pbStar1.Image")));
      this.pbStar1.Location = new System.Drawing.Point(1, 3);
      this.pbStar1.Margin = new System.Windows.Forms.Padding(0);
      this.pbStar1.Name = "pbStar1";
      this.pbStar1.Size = new System.Drawing.Size(16, 16);
      this.pbStar1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
      this.pbStar1.TabIndex = 6;
      this.pbStar1.TabStop = false;
      // 
      // pbStar2
      // 
      this.pbStar2.Image = ((System.Drawing.Image)(resources.GetObject("pbStar2.Image")));
      this.pbStar2.Location = new System.Drawing.Point(18, 3);
      this.pbStar2.Margin = new System.Windows.Forms.Padding(0);
      this.pbStar2.Name = "pbStar2";
      this.pbStar2.Size = new System.Drawing.Size(16, 16);
      this.pbStar2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
      this.pbStar2.TabIndex = 7;
      this.pbStar2.TabStop = false;
      // 
      // pbStar3
      // 
      this.pbStar3.Image = ((System.Drawing.Image)(resources.GetObject("pbStar3.Image")));
      this.pbStar3.Location = new System.Drawing.Point(35, 3);
      this.pbStar3.Margin = new System.Windows.Forms.Padding(0);
      this.pbStar3.Name = "pbStar3";
      this.pbStar3.Size = new System.Drawing.Size(16, 16);
      this.pbStar3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
      this.pbStar3.TabIndex = 8;
      this.pbStar3.TabStop = false;
      // 
      // pbStar4
      // 
      this.pbStar4.Image = ((System.Drawing.Image)(resources.GetObject("pbStar4.Image")));
      this.pbStar4.Location = new System.Drawing.Point(52, 3);
      this.pbStar4.Margin = new System.Windows.Forms.Padding(0);
      this.pbStar4.Name = "pbStar4";
      this.pbStar4.Size = new System.Drawing.Size(16, 16);
      this.pbStar4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
      this.pbStar4.TabIndex = 9;
      this.pbStar4.TabStop = false;
      // 
      // StarRating
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.Transparent;
      this.Controls.Add(this.pbStar5);
      this.Controls.Add(this.pbStar1);
      this.Controls.Add(this.pbStar2);
      this.Controls.Add(this.pbStar3);
      this.Controls.Add(this.pbStar4);
      this.Margin = new System.Windows.Forms.Padding(0);
      this.Name = "StarRating";
      this.Padding = new System.Windows.Forms.Padding(1);
      this.Size = new System.Drawing.Size(88, 22);
      this.Load += new System.EventHandler(this.StarRating_Load);
      ((System.ComponentModel.ISupportInitialize)(this.pbStar5)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar2)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar3)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbStar4)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    internal System.Windows.Forms.PictureBox pbStar5;
    internal System.Windows.Forms.PictureBox pbStar1;
    internal System.Windows.Forms.PictureBox pbStar2;
    internal System.Windows.Forms.PictureBox pbStar3;
    internal System.Windows.Forms.PictureBox pbStar4;
  }
}
