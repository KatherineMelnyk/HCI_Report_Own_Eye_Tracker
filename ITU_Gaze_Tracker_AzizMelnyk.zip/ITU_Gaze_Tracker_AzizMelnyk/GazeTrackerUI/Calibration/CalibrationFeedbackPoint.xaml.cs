﻿namespace GazeTrackerUI.Calibration
{
    public partial class CalibrationFeedbackPoint
    {
        public CalibrationFeedbackPoint()
        {
            InitializeComponent();

            // Insert code required on object creation below this point.
        }
    }
}